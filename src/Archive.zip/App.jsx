import { useEffect, useRef, useState } from "react";
import { Hands } from "@mediapipe/hands";
import { Camera } from "@mediapipe/camera_utils";
import { drawConnectors, drawLandmarks } from "@mediapipe/drawing_utils";
import { motion, AnimatePresence } from "framer-motion";
import { Layers, Volume2, Mic, FileText, X, BookOpen, Activity, Download, Square, GraduationCap } from 'lucide-react';
import GestureGuide from './GestureGuide';
import TrainingPanel from './TrainingPanel';
import "./App.css";

export default function App() {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const [sentence, setSentence] = useState("");
  const sentenceRef = useRef("");
  const [gesture, setGesture] = useState("Waiting...");
  const [confidence, setConfidence] = useState(0);
  const [handDetected, setHandDetected] = useState(false);
  const [isGuideOpen, setIsGuideOpen] = useState(false);
  const lastAddedTime = useRef(0);
  const lastGestureTime = useRef(Date.now());
  const [history, setHistory] = useState([]);
  const [fps, setFps] = useState(0);
  const lastFrameTime = useRef(Date.now());

  // ML State
  const classifier = useRef(null);
  const tfRef = useRef(null);
  const knnModule = useRef(null);
  const [trainingData, setTrainingData] = useState({});
  const mlPredictionRef = useRef(null);
  const trainingLabel = useRef(null);
  const [isTrainingOpen, setIsTrainingOpen] = useState(false);
  const [mlReady, setMlReady] = useState(false);

  // Sync sentenceRef with sentence state for onResults callback
  useEffect(() => {
    sentenceRef.current = sentence;
  }, [sentence]);

  // Load TensorFlow lazily (dynamic import prevents crash)
  useEffect(() => {
    let cancelled = false;
    async function loadML() {
      try {
        const tf = await import('@tensorflow/tfjs');
        const knn = await import('@tensorflow-models/knn-classifier');
        if (!cancelled) {
          tfRef.current = tf;
          knnModule.current = knn;
          classifier.current = knn.create();

          // Restore saved model from localStorage
          try {
            const savedModel = localStorage.getItem('isl-knn-model');
            const savedClasses = localStorage.getItem('isl-knn-classes');
            if (savedModel && savedClasses) {
              const dataset = JSON.parse(savedModel);
              const parsed = {};
              for (const key in dataset) {
                parsed[key] = tf.tensor(dataset[key].data, dataset[key].shape);
              }
              classifier.current.setClassifierDataset(parsed);
              setTrainingData(JSON.parse(savedClasses));
              console.log('✅ Restored saved gestures');
            }
          } catch (e) {
            console.warn('Could not restore saved model:', e);
          }

          setMlReady(true);
          console.log('✅ ML engine loaded');
        }
      } catch (err) {
        console.warn('⚠️ ML engine failed to load:', err);
      }
    }
    loadML();
    return () => { cancelled = true; };
  }, []);

  // Add a new gesture class (just register it with 0 examples)
  const addClass = (label) => {
    setTrainingData(prev => ({
      ...prev,
      [label]: prev[label] || 0
    }));
  };

  // Save model to localStorage
  const saveModel = () => {
    if (!classifier.current || classifier.current.getNumClasses() === 0) return;
    try {
      const dataset = classifier.current.getClassifierDataset();
      const serialized = {};
      for (const key in dataset) {
        serialized[key] = {
          data: Array.from(dataset[key].dataSync()),
          shape: dataset[key].shape
        };
      }
      localStorage.setItem('isl-knn-model', JSON.stringify(serialized));
    } catch (e) {
      console.warn('Could not save model:', e);
    }
  };

  // Start/stop recording examples for a class
  const startRecording = (label) => {
    trainingLabel.current = label;
  };
  const stopRecording = () => {
    trainingLabel.current = null;
    // Auto-save after each recording session
    saveModel();
    // Also save the class names/counts
    setTrainingData(prev => {
      localStorage.setItem('isl-knn-classes', JSON.stringify(prev));
      return prev;
    });
  };

  // Clear a class
  const clearClass = (label) => {
    if (classifier.current) {
      classifier.current.clearClass(label);
      setTrainingData(prev => {
        const newData = { ...prev };
        delete newData[label];
        localStorage.setItem('isl-knn-classes', JSON.stringify(newData));
        return newData;
      });
      if (classifier.current.getNumClasses() === 0) {
        mlPredictionRef.current = null;
        localStorage.removeItem('isl-knn-model');
        localStorage.removeItem('isl-knn-classes');
      } else {
        saveModel();
      }
    }
  };

  useEffect(() => {
    const hands = new Hands({
      locateFile: (file) =>
        `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`,
    });

    hands.setOptions({
      maxNumHands: 1,
      modelComplexity: 1,
      minDetectionConfidence: 0.7,
      minTrackingConfidence: 0.7,
    });

    hands.onResults((results) => {
      const canvasCtx = canvasRef.current.getContext("2d");
      const nowFrame = Date.now();
      const delta = nowFrame - lastFrameTime.current;
      setFps(Math.round(1000 / delta));
      lastFrameTime.current = nowFrame;

      canvasCtx.save();
      canvasCtx.clearRect(
        0,
        0,
        canvasRef.current.width,
        canvasRef.current.height
      );

      canvasCtx.drawImage(
        results.image,
        0,
        0,
        canvasRef.current.width,
        canvasRef.current.height
      );

      if (results.multiHandLandmarks.length > 0) {
        setHandDetected(true);

        if (results.multiHandLandmarks.length > 0) {
          const landmarks = results.multiHandLandmarks[0];

          drawConnectors(canvasCtx, landmarks, Hands.HAND_CONNECTIONS, {
            color: "rgba(224, 225, 221, 0.5)",
            lineWidth: 2,
          });
          drawLandmarks(canvasCtx, landmarks, {
            color: "#E0E1DD",
            lineWidth: 1,
            radius: 2,
          });

          // --- Machine Learning Logic ---
          if (classifier.current && tfRef.current) {
            const tf = tfRef.current;
            const features = tf.tensor(landmarks.map(p => [p.x, p.y, p.z]).flat());

            // Training Mode — continuously captures while button held
            if (trainingLabel.current) {
              classifier.current.addExample(features, trainingLabel.current);
              setTrainingData(prev => ({
                ...prev,
                [trainingLabel.current]: (prev[trainingLabel.current] || 0) + 1
              }));
            }

            // Prediction Mode
            if (classifier.current.getNumClasses() > 0 && !trainingLabel.current) {
              classifier.current.predictClass(features).then(result => {
                if (result.confidences[result.label] > 0.8) {
                  mlPredictionRef.current = { label: result.label, confidence: result.confidences[result.label] };
                } else {
                  mlPredictionRef.current = null;
                }
              });
            }
            features.dispose();
          }

          const prediction = detectGesture(landmarks);
          let finalLabel = prediction.label;
          // Override with ML prediction if confident
          if (mlPredictionRef.current && mlPredictionRef.current.confidence > 0.8) {
            finalLabel = mlPredictionRef.current.label;
          }
          const stable = stablePrediction(finalLabel);

          if (stable) {
            setGesture(stable);
            setConfidence(prediction.confidence);
            lastGestureTime.current = Date.now();
            const now = Date.now();
            if (now - lastAddedTime.current > 1000) {
              setSentence((prev) => prev + stable);
              lastAddedTime.current = now;

              const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
              setHistory((prev) => [
                { id: Date.now(), text: stable, time: timeStr },
                ...prev
              ].slice(0, 50));
            }
          }
        }
      } else {
        setHandDetected(false);
      }

      const now = Date.now();
      // Check lastGestureTime and ensure we don't add space if empty or already has space
      // Using sentenceRef.current to avoid stale closure
      if (now - lastGestureTime.current > 2000 &&
        sentenceRef.current.length > 0 &&
        sentenceRef.current.slice(-1) !== " ") {
        setSentence((prev) => prev + " ");
        lastGestureTime.current = now;
      }
      canvasCtx.restore();
    });

    if (videoRef.current) {
      const camera = new Camera(videoRef.current, {
        onFrame: async () => {
          await hands.send({ image: videoRef.current });
        },
        width: 640,
        height: 480,
      });
      camera.start();
    }
  }, []);


  const speak = (text) => {
    if (!text || text.trim() === '') return;

    // Use ResponsiveVoice for natural human-like voice
    // "UK English Female" often sounds less robotic than the default US one
    if (window.responsiveVoice && window.responsiveVoice.voiceSupport()) {
      window.responsiveVoice.cancel();
      window.responsiveVoice.speak(text, "UK English Female", {
        pitch: 1,
        rate: 0.95, // Slightly slower for clarity
        volume: 1
      });
    } else {
      // Fallback: browser speech with best available natural voice
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      const voices = window.speechSynthesis.getVoices();

      // Pivot to find the most "human-like" system voice available
      const preferredVoice = voices.find(v =>
        v.name.includes("Google US English") ||
        v.name.includes("Samantha") ||
        v.name.includes("Microsoft Zira") ||
        (v.name.includes("English") && v.name.includes("Female"))
      );

      if (preferredVoice) utterance.voice = preferredVoice;
      utterance.rate = 0.9;
      utterance.pitch = 1.05; // Slight pitch lift for warmth
      window.speechSynthesis.speak(utterance);
    }
  };

  const exportText = () => {
    const blob = new Blob([sentence], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "isl-output.txt";
    a.click();
  };

  const detectGesture = (landmarks) => {
    const thumbTip = landmarks[4];
    const indexTip = landmarks[8];
    const middleTip = landmarks[12];
    const ringTip = landmarks[16];
    const pinkyTip = landmarks[20];

    const thumbBase = landmarks[2];
    const indexBase = landmarks[5];
    const middleBase = landmarks[9];
    const ringBase = landmarks[13];
    const pinkyBase = landmarks[17];

    // Helper: Is finger extended?
    const isExtended = (tip, base) => tip.y < base.y;
    // For thumb, we check x distance or y depending on hand orientation, but for simplicity here:
    // Thumb is "extended" if tip is far from base? 
    // Standard approach: Check if tip is above base (like others) OR check angle.
    // For ISL A/B/etc, simplest check:

    // We'll use a simplified y-check for 4 fingers
    const indexUp = isExtended(indexTip, indexBase);
    const middleUp = isExtended(middleTip, middleBase);
    const ringUp = isExtended(ringTip, ringBase);
    const pinkyUp = isExtended(pinkyTip, pinkyBase);

    // Thumb check (more complex due to rotation)
    // Simple check: is thumb tip to the left/right of base?
    // Assuming right hand for now or handling both via relative dist
    const thumbUp = thumbTip.y < thumbBase.y;

    // Helper: Euclidean distance between two landmark points
    const dist = (p1, p2) => Math.sqrt(Math.pow(p1.x - p2.x, 2) + Math.pow(p1.y - p2.y, 2));

    // --- DETECT GESTURES (ordered by specificity: most specific first) ---

    // ===== 4 FINGERS UP =====

    // F: Thumb+Index touch (OK sign), Middle/Ring/Pinky up
    if (dist(thumbTip, indexTip) < 0.05 && middleUp && ringUp && pinkyUp) {
      return { label: "F", confidence: 0.9 };
    }

    // B: All 4 fingers up (flat hand) — thumb can be up or down
    if (indexUp && middleUp && ringUp && pinkyUp) {
      return { label: "B", confidence: 0.9 };
    }

    // ===== 3 FINGERS UP =====

    // W: Index + Middle + Ring up, Pinky down
    if (indexUp && middleUp && ringUp && !pinkyUp) {
      return { label: "W", confidence: 0.9 };
    }

    // ===== 2 FINGERS UP =====

    // R: Index + Middle up, crossed (Index X > Middle X)
    if (indexUp && middleUp && !ringUp && !pinkyUp) {
      if (indexTip.x > middleTip.x + 0.02) {
        return { label: "R", confidence: 0.85 };
      }
    }

    // K: Index + Middle up, thumb touching middle base
    if (indexUp && middleUp && !ringUp && !pinkyUp) {
      const middleMCP = landmarks[9];
      if (dist(thumbTip, middleMCP) < 0.05) {
        return { label: "K", confidence: 0.85 };
      }
    }

    // U: Index + Middle up, together (close tips)
    if (indexUp && middleUp && !ringUp && !pinkyUp) {
      if (dist(indexTip, middleTip) < 0.04) {
        return { label: "U", confidence: 0.85 };
      }
    }

    // V: Index + Middle up, spread apart
    if (indexUp && middleUp && !ringUp && !pinkyUp) {
      return { label: "V", confidence: 0.9 };
    }

    // ===== 1 FINGER UP =====

    // L: Index + Thumb up (L-shape) — MUST check before D
    if (indexUp && thumbUp && !middleUp && !ringUp && !pinkyUp) {
      return { label: "L", confidence: 0.9 };
    }

    // D: Index up only (others curled)
    if (indexUp && !middleUp && !ringUp && !pinkyUp) {
      return { label: "D", confidence: 0.85 };
    }

    // Y: Pinky + Thumb up (Hang loose) — MUST check before I
    if (!indexUp && !middleUp && !ringUp && pinkyUp && thumbUp) {
      return { label: "Y", confidence: 0.9 };
    }

    // I: Pinky up only
    if (!indexUp && !middleUp && !ringUp && pinkyUp) {
      return { label: "I", confidence: 0.9 };
    }

    // ===== 0 FINGERS UP (FIST VARIANTS) =====

    // O: Thumb touching Index+Middle tips (circle shape)
    if (dist(thumbTip, indexTip) < 0.05 && dist(thumbTip, middleTip) < 0.05) {
      return { label: "O", confidence: 0.85 };
    }

    // A: Fist with thumb up/to the side
    if (!indexUp && !middleUp && !ringUp && !pinkyUp && thumbUp) {
      return { label: "A", confidence: 0.9 };
    }

    // E: Fist with thumb tucked under
    if (!indexUp && !middleUp && !ringUp && !pinkyUp && !thumbUp) {
      if (thumbTip.y > indexBase.y) {
        return { label: "E", confidence: 0.8 };
      }
    }

    // S: Fist with thumb over fingers (default fist)
    if (!indexUp && !middleUp && !ringUp && !pinkyUp && !thumbUp) {
      return { label: "S", confidence: 0.8 };
    }

    return { label: "Unknown", confidence: 0 };
  };

  const predictionBuffer = useRef([]);

  const stablePrediction = (label) => {
    predictionBuffer.current.push(label);

    if (predictionBuffer.current.length > 10) {
      predictionBuffer.current.shift();
    }

    const counts = {};
    predictionBuffer.current.forEach((l) => {
      counts[l] = (counts[l] || 0) + 1;
    });

    const mostCommon = Object.keys(counts).reduce((a, b) =>
      counts[a] > counts[b] ? a : b
    );

    if (counts[mostCommon] >= 7 && mostCommon !== "Unknown") {
      return mostCommon;
    }

    return null;
  };

  return (
    <>
      <div className="app-container">
        {/* Main Camera Stage */}
        <div className="main-stage">

          {/* Header / Top Bar */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <div style={{ padding: '8px', background: 'rgba(255, 255, 255, 0.1)', borderRadius: '12px' }}>
                <Layers className="text-accent" size={24} color="#E0E1DD" />
              </div>
              <div>
                <h1 style={{ margin: 0, fontSize: '24px', fontWeight: 700, letterSpacing: '-0.5px', lineHeight: 1 }}>
                  ISL <span style={{ color: 'var(--text-muted)' }}>Translate</span>
                </h1>
              </div>
            </div>

            <div style={{ display: 'flex', gap: '10px' }}>
              <button
                className="btn-secondary"
                onClick={() => setIsTrainingOpen(true)}
                style={{
                  background: isTrainingOpen ? 'var(--accent)' : 'rgba(255,255,255,0.05)',
                  color: isTrainingOpen ? 'black' : 'white',
                  padding: '8px 12px',
                  borderRadius: '8px',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  border: '1px solid rgba(255,255,255,0.1)',
                  cursor: 'pointer'
                }}
              >
                <GraduationCap size={18} />
                <span style={{ fontSize: '13px', fontWeight: 600 }}>Train</span>
              </button>

              <button
                onClick={() => setIsGuideOpen(true)}
                className="btn-secondary"
                style={{
                  padding: '8px 12px',
                  borderRadius: '8px',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  border: '1px solid rgba(255,255,255,0.1)',
                  background: 'rgba(255,255,255,0.05)',
                  cursor: 'pointer'
                }}
              >
                <BookOpen size={18} />
                <span style={{ fontSize: '13px', fontWeight: 600 }}>Gestures</span>
              </button>
            </div>

            <div style={{ display: 'flex', gap: '20px' }}>
              <div className="live-indicator" style={{ background: 'rgba(15, 23, 42, 0.5)' }}>
                <Activity size={14} color="var(--primary)" />
                <span>Live Feed</span>
                <div className="dot"></div>
              </div>
            </div>
          </div>

          <div className="camera-wrapper">
            <div className="overlay-top-left">
              <div className="live-indicator">
                <div className="dot"></div> Live Feed
              </div>
            </div>

            <AnimatePresence>
              {!handDetected && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  style={{
                    position: 'absolute',
                    top: '50%',
                    left: '50%',
                    transform: 'translate(-50%, -50%)',
                    background: 'rgba(0,0,0,0.7)',
                    padding: '12px 24px',
                    borderRadius: '99px',
                    border: '1px solid var(--glass-border)',
                    color: 'white',
                    fontWeight: 500,
                    backdropFilter: 'blur(10px)',
                    zIndex: 20
                  }}
                >
                  Waiting for gesture...
                </motion.div>
              )}
            </AnimatePresence>

            <video ref={videoRef} style={{ display: "none" }} />
            <canvas ref={canvasRef} width="640" height="480" className="camera-feed" />
          </div>

          {/* Real-time Metrics Panel */}
          <div className="glass-panel gesture-display">
            <div>
              <span className="text-overline">Detected Gesture</span>
              <div className="text-value" style={{ color: 'var(--accent)' }}>
                {gesture === "Waiting..." ? <span style={{ opacity: 0.3, fontSize: '24px' }}>Waiting...</span> : gesture}
              </div>
            </div>

            <div style={{ flex: 1, marginLeft: '40px', maxWidth: '300px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
                <span className="text-overline" style={{ margin: 0 }}>Model Confidence</span>
                <span className="text-overline" style={{ margin: 0, color: 'var(--text-main)' }}>{(confidence * 100).toFixed(0)}%</span>
              </div>
              <div className="confidence-meter">
                <div
                  className="confidence-fill"
                  style={{ width: `${confidence * 100}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar Control Panel */}
        <div className="control-sidebar">
          {/* Output Section */}
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: '10px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span className="text-overline">Translation Output</span>
              <span className="text-overline" style={{ color: 'var(--text-main)', cursor: 'pointer' }} onClick={() => setSentence("")}>Clear</span>
            </div>
            <textarea
              className="output-box"
              value={sentence}
              onChange={(e) => setSentence(e.target.value)}
              placeholder="Translated text will appear here..."
              spellCheck="false"
              style={{
                width: '100%',
                resize: 'none',
                backgroundColor: 'var(--bg-deep)',
                border: '1px solid var(--bg-surface)',
                outline: 'none',
                color: 'var(--text-main)',
                padding: '16px',
                borderRadius: '8px',
                fontSize: '18px',
                lineHeight: '1.6',
                fontFamily: 'inherit'
              }}
            />
          </div>

          {/* Action Buttons */}
          <div className="action-grid">
            <button className="btn btn-primary" onClick={() => speak(sentence)}>
              <Mic size={18} /> Speak
            </button>
            <button className="btn btn-secondary" onClick={exportText}>
              <Download size={18} /> Export
            </button>
            <button
              onClick={() => setSentence("")}
              style={{
                gridColumn: 'span 2',
                background: 'rgba(224, 225, 221, 0.1)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: 'pointer',
                color: 'rgb(224, 225, 221)',
                transition: '0.2s',
                transform: 'scale(1)',
                border: 'none',
                borderRadius: '8px',
                padding: '12px',
                gap: '8px',
                fontFamily: 'Space Grotesk',
                fontWeight: 600
              }}
            >
              <X size={18} strokeWidth={2.5} /> Clear Output
            </button>
          </div>

          {/* History Section */}
          <div className="glass-panel" style={{ height: '35%', display: 'flex', flexDirection: 'column' }}>
            <span className="text-overline">Detection History</span>
            <div className="history-log" style={{ flex: 1 }}>
              <AnimatePresence mode="popLayout">
                {history.map((item) => (
                  <motion.div
                    key={item.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    className="history-item"
                  >
                    <span className="history-time">{item.time}</span>
                    <span style={{ fontWeight: 500 }}>{item.text}</span>
                  </motion.div>
                ))}
              </AnimatePresence>
              {history.length === 0 && (
                <div style={{ textAlign: 'center', padding: '20px', color: 'var(--text-dim)', fontSize: '13px' }}>
                  No gestures detected yet
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <GestureGuide isOpen={isGuideOpen} onClose={() => setIsGuideOpen(false)} />

      <TrainingPanel
        isOpen={isTrainingOpen}
        onClose={() => setIsTrainingOpen(false)}
        trainingData={trainingData}
        onAddClass={addClass}
        onStartRecording={startRecording}
        onStopRecording={stopRecording}
        onClearClass={clearClass}
        mlReady={mlReady}
      />
    </>
  );
}